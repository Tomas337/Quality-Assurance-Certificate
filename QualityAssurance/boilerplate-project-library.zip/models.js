const mongoose = require('mongoose');
const { Schema } = require('mongoose');

const BookSchema = new Schema({
  title: { type: String, required: true },
  comments: [String],
  commentcount: Number
});
const Book = mongoose.model('Book', BookSchema);

exports.Book = Book;