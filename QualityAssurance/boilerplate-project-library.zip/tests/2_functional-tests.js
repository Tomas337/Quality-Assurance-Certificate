/*
*
*
*       FILL IN EACH FUNCTIONAL TEST BELOW COMPLETELY
*       -----[Keep the tests in the same order!]-----
*       
*/

const chaiHttp = require('chai-http');
const chai = require('chai');
const assert = chai.assert;
const server = require('../server');

chai.use(chaiHttp);

suite('Functional Tests', function() {

  /*
  * ----[EXAMPLE TEST]----
  * Each test should completely test the response of the API end-point including response status code!
  */
  test('#example Test GET /api/books', function(done){
     chai.request(server)
      .get('/api/books')
      .end(function(err, res){
        assert.equal(res.status, 200);
        assert.isArray(res.body, 'response should be an array');
        assert.property(res.body[0], 'commentcount', 'Books in array should contain commentcount');
        assert.property(res.body[0], 'title', 'Books in array should contain title');
        assert.property(res.body[0], '_id', 'Books in array should contain _id');
        done();
      });
  });
  /*
  * ----[END of EXAMPLE TEST]----
  */

  suite('Routing tests', function() {

      test('Test POST /api/books with title', function(done) {
        chai
          .request(server)
          .keepOpen()
          .post('/api/books')
          .set("content-type", "application/json")
          .send({ title: "test" })
          .end((err, res) => {     
            assert.equal(res.status, 200);
            bookID = res.body._id;
            assert.equal(res.body.title, "test"); 
            done()
          })
      });
      
      test('Test POST /api/books with no title given', function(done) {
        chai
          .request(server)
          .keepOpen()
          .post('/api/books')
          .end((err, res) => {
            assert.equal(res.status, 200);
            assert.equal(res.text, "missing required field title");
            done()
          })
      });
 
      test('Test GET /api/books',  function(done){
        chai
          .request(server)
          .keepOpen()
          .get('/api/books')
          .end((err, res) => {
            assert.equal(res.status, 200);
            assert.isArray(res.body, 'response should be an array');
            done()
          })
      });      

      test('Test GET /api/books/[id] with id not in db',  function(done){
        chai
          .request(server)
          .keepOpen()
          .get('/api/books/64a6bbcb6f4c023ccceab9f3')
          .end((err, res) => {
            assert.equal(res.status, 200);
            assert.equal(res.text, "no book exists");
            done()
          })
      });

      test('Test GET /api/books/[id] with valid id in db',  function(done){
        chai
          .request(server)
          .keepOpen()
          .get(`/api/books/${bookID}`)
          .end((err, res) => {
            assert.equal(res.status, 200);
            assert.property(res.body, 'commentcount', 'should contain commentcount');
            assert.property(res.body, 'title', 'should contain title');
            assert.property(res.body, '_id', 'should contain _id');
            done()
          })
      });
    
    test('Test POST /api/books/[id] with comment', function(done){
        chai
          .request(server)
          .keepOpen()
          .post(`/api/books/${bookID}`)
          .set("content-type", "application/json")
          .send({ comment: "test" })
          .end((err, res) => {
            assert.equal(res.status, 200);
            assert.property(res.body, 'commentcount', 'should contain commentcount');
            assert.property(res.body, 'title', 'should contain title');
            assert.property(res.body, '_id', 'should contain _id');
            assert.isArray(res.body.comments, 'should be an array')
            assert.equal(res.body.comments[0], "test")
            done()
          })
      });

      test('Test POST /api/books/[id] without comment field', function(done){
        chai
          .request(server)
          .keepOpen()
          .post(`/api/books/${bookID}`)
          .end((err, res) => {
            assert.equal(res.status, 200);
            assert.equal(res.text, "missing required field comment")
            done()
          })
      });

      test('Test POST /api/books/[id] with comment, id not in db', function(done){
        chai
          .request(server)
          .keepOpen()
          .post(`/api/books/64a6bbcb6f4c023ccceab9f3`)
          .set("content-type", "application/json")
          .send({ comment: "test" })
          .end((err, res) => {
            assert.equal(res.status, 200);
            assert.equal(res.text, "no book exists")
            done()
          })
      });

      test('Test DELETE /api/books/[id] with valid id in db', function(done){
        chai
          .request(server)
          .keepOpen()
          .delete(`/api/books/${bookID}`)
          .end((err, res) => {
            assert.equal(res.status, 200);
            assert.equal(res.text, "delete successful");
            done();
          })
      });

      test('Test DELETE /api/books/[id] with id not in db', function(done){
        chai
          .request(server)
          .keepOpen()
          .delete(`/api/books/${bookID}`)
          .end((err, res) => {
            assert.equal(res.status, 200);
            assert.equal(res.text, "no book exists");
            done();
          })
      });

  });

});
