/*
*
*
*       Complete the API routing below
*       
*       
*/

'use strict';
const mongoose = require('mongoose');
const BookModel = require('../models.js').Book;
const ObjectId = require('mongodb').ObjectId;

module.exports = function (app) {

  app.route('/api/books')
    .get(async function (req, res){
      //response will be array of book objects
      //json res format: [{"_id": bookid, "title": book_title, "commentcount": num_of_comments },...]
      try {
        const findBooks = await BookModel.find();
        res.json(findBooks);
      } catch(err){
        console.log(err)
      }      
    })
    
    .post(async function (req, res){
      //response will contain new book object including atleast _id and title
      let title = req.body.title;
      
      if(!title) {
        res.send('missing required field title');
        return;
      }
      const newBook = new BookModel({
        title,
        comments: [],
        commentcount: 0
      });
      newBook.save();

      const findBook = await BookModel.findOne({title});
      if(findBook){
        res.json({ _id: findBook._id, title});
      }   
    })
    
    .delete(async function(req, res){
      //if successful response will be 'complete delete successful'
      try {
        const booksDeleted = await BookModel.deleteMany({});
        res.send("complete delete successful");
      } catch(err) {
        console.log(err);
      }
      
    });



  app.route('/api/books/:id')
    .get(async function (req, res){
      let bookid = req.params.id;
      //json res format: {"_id": bookid, "title": book_title, "comments": [comment,comment,...]}
      try {
        const findBook = await BookModel.findById(bookid);
        if(!findBook){
          res.send("no book exists");
        } else{
          res.json(findBook);
        }     
      } catch(err){
        console.log(err);
      }
    })
    
    .post(async function(req, res){
      //json res format same as .get
      let bookid = req.params.id;
      let comment = req.body.comment;
      try{
        if(!comment){
          res.send("missing required field comment");
          return;
        } 
        const book = await BookModel.findById(bookid);
        
        if(!book){
          res.send("no book exists");
          return;
        }
        book.comments.push(comment);
        book.commentcount = book.comments.length;
        book.save();
        res.json(book);
        
      } catch(err){
        console.log(err);
      } 
    })
    
    .delete(async function(req, res){
      //if successful response will be 'delete successful'
      let bookid = req.params.id;
      const deletedBook = await BookModel.deleteOne({ _id: new ObjectId(bookid) });
      
      if(deletedBook.deletedCount == 0){
        res.send("no book exists");
      } else{
        res.send("delete successful");
      }
    });
  
};
