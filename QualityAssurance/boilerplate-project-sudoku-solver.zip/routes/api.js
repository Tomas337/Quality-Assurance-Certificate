'use strict';

const SudokuSolver = require('../controllers/sudoku-solver.js');

module.exports = function (app) {
  
  let solver = new SudokuSolver();

  app.route('/api/check')
    .post((req, res) => {    
      const puzzleString = req.body.puzzle;
      const value = req.body.value;

      if(req.body.coordinate == undefined || puzzleString == undefined || value == undefined){
        res.json({ "error": "Required field(s) missing" });
        return;
      } 
      if(solver.validate(puzzleString)){
        res.json(solver.validate(puzzleString));
        return;
      }
      if(!/^[a-iA-I][1-9]$/.test(req.body.coordinate)){
        res.json({ error: 'Invalid coordinate'});
        return;
      }
      if(!(value > 0 && value < 10)){
        res.json({ error: 'Invalid value' });
        return;
      }
      
      const [row, column] = req.body.coordinate.split("");

      let invalidResult = { valid: false, conflict: [] }
      if(!solver.checkRowPlacement(puzzleString, row, column, value)){
        invalidResult.conflict.push("row");
      }
      if(!solver.checkColPlacement(puzzleString, row, column, value)){
        invalidResult.conflict.push("column");
      }
      if(!solver.checkRegionPlacement(puzzleString, row, column, value)){
        invalidResult.conflict.push("region");
      }
      
      if(invalidResult.conflict.length == 0){
        res.json({ "valid": true });
      } else{
        res.json(invalidResult);
      }
    });
    
  app.route('/api/solve')
    .post((req, res) => {
      const { puzzle } = req.body;
      if(!puzzle){
        res.json({ error: 'Required field missing' });
        return;
      }
      if(solver.validate(puzzle)){
        res.json(solver.validate(puzzle));
        return;
      }
      try{
        let puzzleArr = [];
        for(let i = 0; i < 81; i+=9){
          puzzleArr.push(puzzle.slice(i, i+9).split(""))
        }
        res.json({ solution: solver.solve(puzzleArr).flat().join("") })
      } catch(err){
        res.json({ error: 'Puzzle cannot be solved' })
      }
      
    });
};
