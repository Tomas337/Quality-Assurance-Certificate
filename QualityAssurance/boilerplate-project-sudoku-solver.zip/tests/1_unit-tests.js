const chai = require('chai');
const assert = chai.assert;
const expect = chai.expect;

const Solver = require('../controllers/sudoku-solver.js');
let solver = new Solver();

suite('Unit Tests', () => {
  test("Logic handles a valid puzzle string of 81 characters", () => {
    assert.equal(solver.validate("..9..5.1.85.4....2432......1...69.83.9.....6.62.71...9......1945....4.37.4.3..6.."), false)
  });
  test("Logic handles a puzzle string with invalid characters (not 1-9 or .)", () => {
    assert.deepEqual(solver.validate("..9..5.1.85.4....2432......1...69.83.9.....6.62.71...9......1945....4.37.4.3..6Aa"), { "error": "Invalid characters in puzzle" })
  });
  test("Logic handles a puzzle string that is not 81 characters in length", () => {
    assert.deepEqual(solver.validate("..9..5.1.85.4....2432......1...69.83.9.....6.62.71...9......1945....4.37.4.3.."), { "error": "Expected puzzle to be 81 characters long" })
  });
  test("Logic handles a valid row placement", () => {
    assert.equal(solver.checkRowPlacement("..9..5.1.85.4....2432......1...69.83.9.....6.62.71...9......1945....4.37.4.3..6..", "I", "9", "9"), true)
  });
  test("Logic handles an invalid row placement", () => {
    assert.equal(solver.checkRowPlacement("..9..5.1.85.4....2432......1...69.83.9.....6.62.71...9......1945....4.37.4.3..6..", "A", "1", "1"), false)
  });
  test("Logic handles a valid column placement", () => {
    assert.equal(solver.checkColPlacement("..9..5.1.85.4....2432......1...69.83.9.....6.62.71...9......1945....4.37.4.3..6..", "A", "1", "7"), true)
  });
  test("Logic handles an invalid column placement", () => {
    assert.equal(solver.checkColPlacement("..9..5.1.85.4....2432......1...69.83.9.....6.62.71...9......1945....4.37.4.3..6..", "A", "1", "1"), false)
  });
  test("Logic handles a valid region (3x3 grid) placement", () => {
    assert.equal(solver.checkRegionPlacement("..9..5.1.85.4....2432......1...69.83.9.....6.62.71...9......1945....4.37.4.3..6..", "A", "1", "7"), true)
  });
  test("Logic handles an invalid region (3x3 grid) placement", () => {
    assert.equal(solver.checkRegionPlacement("..9..5.1.85.4....2432......1...69.83.9.....6.62.71...9......1945....4.37.4.3..6..", "A", "1", "2"), false)
  });
  test("Valid puzzle strings pass the solver", () => {
    let puzzle = "..9..5.1.85.4....2432......1...69.83.9.....6.62.71...9......1945....4.37.4.3..6..";
    let puzzleArr = [];
    for(let i = 0; i < 81; i+=9){
      puzzleArr.push(puzzle.slice(i, i+9).split(""))
    }
    assert.equal(solver.solve(puzzleArr).flat().join(""), "769235418851496372432178956174569283395842761628713549283657194516924837947381625")
  });
  test("Invalid puzzle strings fail the solver", () => {
    let puzzle = "..9..5.1.85.4....2432......1...69.83.9.....6.62.71...9......1945....4.37.4.3..666";
    let puzzleArr = [];
    for(let i = 0; i < 81; i+=9){
      puzzleArr.push(puzzle.slice(i, i+9).split(""))
    }
    assert.equal(solver.solve(puzzleArr), undefined)
  });
  test("Solver returns the expected solution for an incomplete puzzle", () => {
    let puzzle = "..9..5.1.85.4....2432......1...69.83.9.....6.62.71...9......1945....4.37.4.3..6..";
    let puzzleArr = [];
    for(let i = 0; i < 81; i+=9){
      puzzleArr.push(puzzle.slice(i, i+9).split(""))
    }
    assert.equal(solver.solve(puzzleArr).flat().join(""), '769235418851496372432178956174569283395842761628713549283657194516924837947381625')
  });

});
