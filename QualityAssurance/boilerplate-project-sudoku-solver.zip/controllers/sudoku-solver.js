class SudokuSolver {

  validate(puzzleString) {
    if(puzzleString.length != 81){
      return { "error": "Expected puzzle to be 81 characters long" };
    }
    if(!/[1-9.]{81}/.test(puzzleString)){
      return { "error": "Invalid characters in puzzle" };
    }
    return false;
  }

  checkRowPlacement(puzzleString, row, column, value) {
    const rowBeginning = {
      "A": 0,
      "B": 9,
      "C": 18,
      "D": 27,
      "E": 36,
      "F": 45,
      "G": 54,
      "H": 63,
      "I": 72
    };
    row = row.toUpperCase();
    const rowArr = puzzleString.slice(rowBeginning[row], rowBeginning[row]+9).split("");
    return (rowArr[column-1] == value && ![...rowArr.slice(0, column-1), ...rowArr.slice(column)].includes(value)) || !rowArr.includes(value);
  }

  checkColPlacement(puzzleString, row, column, value) {
    const rowIndexes = {
      "A": 0,
      "B": 1,
      "C": 2,
      "D": 3,
      "E": 4,
      "F": 5,
      "G": 6,
      "H": 7,
      "I": 8
    };
    const rowIndex = rowIndexes[row.toUpperCase()];
    
    let columnArr = [];
    for(let i = 0; i < 81; i+=9){
      columnArr.push(puzzleString.charAt(column-1 + i));
    }
    return (columnArr[rowIndex] == value && ![...columnArr.slice(0, rowIndex), ...columnArr.slice(rowIndex+1)].includes(value)) || !columnArr.includes(value);
  }

  checkRegionPlacement(puzzleString, row, column, value) {
    const rowIndexes = {
      "A": 0,
      "B": 9,
      "C": 18,
      "D": 27,
      "E": 36,
      "F": 45,
      "G": 54,
      "H": 63,
      "I": 72
    };
    row = row.toUpperCase();
    const rowIndex = rowIndexes[row];
    
    let rowBeginning;
    if(rowIndex <= 18){
      rowBeginning = 0;
    } else if(rowIndex <= 45){
      rowBeginning = 27;
    } else{
      rowBeginning = 54;
    }

    let columnBeginning;
    if(column <= 3){
      columnBeginning = 0;
    } else if(column <= 6){
      columnBeginning = 3;
    } else{
      columnBeginning = 6;
    }

    let region = [];
    const end = rowBeginning+18;
    const puzzleArr = puzzleString.split("");
    for(let i = rowBeginning; i <= end; i+=9){
      region.push(...puzzleArr.slice(i+columnBeginning, i+columnBeginning+3))
    }

    let regionRowBegin;
    if(row == "A" || row == "D" || row == "G"){
      regionRowBegin = 0;
    } else if(row == "B" || row == "E" || row == "H"){
      regionRowBegin = 3;
    } else{
      regionRowBegin = 6;
    }
    let regionColumn;
    if(column == 1 || column == 4 || column == 7){
      regionColumn = 0;
    } else if(column == 2 || column == 5 || column == 8){
      regionColumn = 1;
    } else{
      regionColumn = 2;
    }

    return (region[regionRowBegin+regionColumn] == value && ![...region.slice(0, regionRowBegin+regionColumn), ...region.slice(regionRowBegin+regionColumn+1)].includes(value)) || !region.includes(value);
  }

  solve(puzzle) {
    for(let y = 0; y < 9; y++){
      const rowLetters = {
        0: "A",
        1: "B",
        2: "C",
        3: "D",
        4: "E",
        5: "F",
        6: "G",
        7: "H",
        8: "I"
      };
      const row = rowLetters[y];
      for(let x = 0; x < 9; x++){
        if(puzzle[y][x] == "."){
          for(let n = 1; n < 10; n++){
            if(this.checkRowPlacement(puzzle.flat().join(""), row, String(x+1), String(n)) && this.checkColPlacement(puzzle.flat().join(""), row, String(x+1), String(n)) && this.checkRegionPlacement(puzzle.flat().join(""), row, String(x+1), String(n))){            
              puzzle[y][x] = n;
              if (this.solve(puzzle)) {
                return puzzle;
              }
              puzzle[y][x] = ".";
            }
          }
          return;
        }
      }
    }
    return puzzle;
  }
}

module.exports = SudokuSolver;

