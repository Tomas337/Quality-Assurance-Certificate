function ConvertHandler() {
  
  this.getNum = function(input) {
    let expression = input.replace(/[A-Za-z]+$/, "");
    if( ! expression ) return 1;
    
    if( ! /^[0-9]+(\.[0-9]+)?(\/[0-9]+(\.[0-9]+)?)?$/.test(expression) ) return "invalid number";
    
    result = eval(expression);
    return Number(result.toFixed(5));
  };
  
  this.getUnit = function(input) {
    let unit = input.replace(/^[^A-Za-z]+/, "");
    unit = unit.toLowerCase();
    
    //if(unit == "") return "invalid unit";

    const units = ["gal", "l", "mi", "km", "lbs", "kg"];
    if(!units.includes(unit)) return "invalid unit";
    
    return unit;
  };
  
  this.getReturnUnit = function(initUnit) {
    const units = {
      "gal": "l",
      "l": "gal",
      "mi": "km",
      "km": "mi",
      "lbs": "kg",
      "kg": "lbs"
    }
    let returnUnit = units[initUnit];
    
    if(typeof returnUnit == "undefined") return "invalid unit";
    return returnUnit;
  };

  this.spellOutUnit = function(unit) {
    const units = {
      "gal": "gallons",
      "l": "liters",
      "mi": "miles",
      "km": "kilometers",
      "lbs": "pounds",
      "kg": "kilograms"
    }

    let returnUnit = units[unit];
    
    return returnUnit;
  };
  
  this.convert = function(initNum, initUnit) {
    const galToL = 3.78541;
    const lbsToKg = 0.453592;
    const miToKm = 1.60934;

    switch(initUnit) {
      case 'l':
        return Number((initNum / galToL).toFixed(5));
      case 'gal':
        return Number((initNum * galToL).toFixed(5));
      case 'kg':
        return Number((initNum / lbsToKg).toFixed(5));
      case 'lbs':
        return Number((initNum * lbsToKg).toFixed(5));
      case 'km':
        return Number((initNum / miToKm).toFixed(5));
      case 'mi':
        return Number((initNum * miToKm).toFixed(5));
    }

  };
  
  this.getString = function(initNum, initUnit, returnNum, returnUnit) {
    let string = `${initNum} ${initUnit} converts to ${returnNum} ${returnUnit}`;
    return string;
  };
  
}

module.exports = ConvertHandler;
