'use strict';

const expect = require('chai').expect;
const ConvertHandler = require('../controllers/convertHandler.js');

module.exports = function (app) {
  
  let convertHandler = new ConvertHandler();

  app.get('/api/convert', (req, res) => {
    let {input} = req.query;
    if( typeof input != "undefined"){
      let initNum = convertHandler.getNum(input);
      let initUnit = convertHandler.getUnit(input);
      let returnUnit = convertHandler.getReturnUnit(initUnit);

      if(returnUnit == "invalid unit" && initNum == "invalid number"){
        res.send("invalid number and unit");
      }
      else if(returnUnit == "invalid unit") {
        res.send("invalid unit");
      }
      else if(initNum == "invalid number"){
        res.send("invalid number");
      }
      else {
        let returnNum = convertHandler.convert(initNum, initUnit);
        
        //initNum = Number(initNum.toFixed(5));
        
        let string = convertHandler.getString(initNum, convertHandler.spellOutUnit(initUnit), returnNum, convertHandler.spellOutUnit(returnUnit));

        if(initUnit == 'l') { initUnit = initUnit.toUpperCase(); }   
        if(returnUnit == 'l') { returnUnit = returnUnit.toUpperCase(); }
        
        res.json( { initNum , initUnit , returnNum , returnUnit , string } );
      } 
      
    } else {
      res.send("No input")
    }
  })
};
