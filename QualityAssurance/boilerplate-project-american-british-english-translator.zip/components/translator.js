const americanOnly = require('./american-only.js');
const americanToBritishSpelling = require('./american-to-british-spelling.js');
const americanToBritishTitles = require("./american-to-british-titles.js")
const britishOnly = require('./british-only.js')

class Translator {
  americanToBritish(text){
    const americanWords = [...Object.keys(americanOnly), ...Object.keys(americanToBritishSpelling), ...Object.keys(americanToBritishTitles)]
    const britishWords = [...Object.values(americanOnly), ...Object.values(americanToBritishSpelling), ...Object.values(americanToBritishTitles)]  

    let translatedText = text;
    
    for(let i = 0; i < americanWords.length; i++){
      const regexLowerCase = new RegExp("(\\b)" + americanWords[i] + "(\\b|(?<=\.))", "g");
      const regexUpperCase = new RegExp("(\\b)" + americanWords[i].charAt(0).toUpperCase() + americanWords[i].slice(1) + "(\\b|(?<=\.))", "g");
      translatedText = translatedText.replace(regexLowerCase, `$1<span class="highlight">` + britishWords[i] + `</span>$2`);
      translatedText = translatedText.replace(regexUpperCase, `$1<span class="highlight">` + britishWords[i].charAt(0).toUpperCase() + britishWords[i].slice(1) + `</span>$2`)
    }
    translatedText = translatedText.replace(/([0-9]+):([0-9]+)/g, `<span class="highlight">$1.$2</span>`);

    if(translatedText == text) return "Everything looks good to me!";
    return translatedText;
  }

  britishToAmerican(text){  
    const britishWords = [...Object.keys(britishOnly), ...Object.values(americanToBritishSpelling), ...Object.values(americanToBritishTitles)]
    const americanWords = [...Object.values(britishOnly), ...Object.keys(americanToBritishSpelling), ...Object.keys(americanToBritishTitles)]

    let translatedText = text;

    for(let i = 0; i < britishWords.length; i++){ 
      const regexLowerCase = new RegExp("(\\b)" + britishWords[i] + "(\\b)", "g");
      const regexUpperCase = new RegExp("(\\b)" + britishWords[i].charAt(0).toUpperCase() + britishWords[i].slice(1) + "(\\b)", "g");
      if((translatedText.match(regexLowerCase) || translatedText.match(regexUpperCase)) && britishWords[i] == "chippy") ++i;
      translatedText = translatedText.replace(regexLowerCase, `$1<span class="highlight">` + americanWords[i] + `</span>$2`);
      translatedText = translatedText.replace(regexUpperCase, `$1<span class="highlight">` + americanWords[i].charAt(0).toUpperCase() + americanWords[i].slice(1) + `</span>$2`) 
        
    }

    translatedText = translatedText.replace(/([0-9]+).([0-9]+)/g, `<span class="highlight">$1:$2</span>`);
    
    if(translatedText == text) return "Everything looks good to me!";
    return translatedText;
  }
}

module.exports = Translator;